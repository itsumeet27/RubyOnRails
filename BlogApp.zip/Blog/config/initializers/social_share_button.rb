SocialShareButton.configure do |config|
  config.allow_sites = %w(twitter facebook google_plus tumblr pinterest email linkedin instagram whatsapp_app whatsapp_web)
end
